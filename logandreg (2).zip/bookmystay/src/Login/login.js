import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import "../Login/login.css";

const Login = ({ history }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [passwordWarning, setPasswordWarning] = useState(false);

  const handleLogin = (e) => {
    e.preventDefault();
    if (password.length < 8) {
      setPasswordWarning(true);
      return; // Prevent login if password length is less than 8 characters
    }
    // Simulate successful login for any username and password combination
    toast.success('Login successful!', {
      position: toast.POSITION.TOP_RIGHT,
      autoClose: 2000,
      
    });
    // Redirect user to the home page after successful login
 
  };

  const handleForgotPassword = () => {
    // Implement password reset functionality
    // Redirect to a password reset page or send a reset link via email
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
    if (e.target.value.length >= 8) {
      setPasswordWarning(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>Welcome to BookMyStay</h2>
        <form onSubmit={handleLogin} className="login-form">
          <div className="form-group">
            <label htmlFor="username">Username:</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={handlePasswordChange}
              required
            />
            {passwordWarning && (
              <span className="warning">Password must be at least 8 characters</span>
            )}
          </div>
          <div className="form-group">
            <button type="submit">Login</button>
            <a href="#" onClick={handleForgotPassword}>
              Forgot Password?
            </a>
            <Link to="/signup">Sign Up</Link>
          </div>
        </form>
        <ToastContainer position="top-right" />
      </div>
    </div>
  );
};

export default Login;
