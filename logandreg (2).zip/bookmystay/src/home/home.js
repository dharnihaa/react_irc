import React from 'react';

const Home = () => {
  return (
    <div>
      <h2>Welcome to BookMyStay! This is the Home Page.</h2>
      {/* Add your home page content here */}
    </div>
  );
};

export default Home;
